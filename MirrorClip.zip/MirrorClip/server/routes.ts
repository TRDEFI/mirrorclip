import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { authService } from "./services/auth";
import { youtubeService } from "./services/youtube";
import { queueService } from "./services/queue";
import { insertChannelSchema, insertJobSchema } from "@shared/schema";
import { randomUUID } from "crypto";

interface AuthenticatedRequest extends Request {
  userId?: string;
}

// Simple session middleware (in production, use proper session management)
const sessions = new Map<string, { userId: string; expiresAt: number }>();

function authMiddleware(req: AuthenticatedRequest, res: Response, next: Function) {
  const sessionId = req.headers.authorization?.replace("Bearer ", "");
  
  if (!sessionId) {
    return res.status(401).json({ error: "No session token provided" });
  }

  const session = sessions.get(sessionId);
  if (!session || session.expiresAt < Date.now()) {
    sessions.delete(sessionId);
    return res.status(401).json({ error: "Invalid or expired session" });
  }

  req.userId = session.userId;
  next();
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Demo auth route
  app.post("/api/auth/demo", async (req, res) => {
    try {
      const { email } = req.body;
      
      // Create or get demo user
      let user = await storage.getUserByEmail(email);
      if (!user) {
        user = await storage.createUser({
          email,
          name: "Demo User",
        });
      }

      // Create demo accounts (simulated connections)
      const existingYouTube = await storage.getAccountByProvider(user.id, "youtube");
      if (!existingYouTube) {
        await storage.createAccount({
          userId: user.id,
          provider: "youtube",
          providerAccountId: "demo-youtube-id",
          accessToken: "demo-youtube-token",
          refreshToken: "demo-youtube-refresh",
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          tokenType: "Bearer",
          scope: "youtube.upload youtube.readonly",
          verified: true,
          channelId: "UCdemo-youtube-channel",
          channelName: "Demo YouTube Channel",
        });
      }

      const existingTikTok = await storage.getAccountByProvider(user.id, "tiktok");
      if (!existingTikTok) {
        await storage.createAccount({
          userId: user.id,
          provider: "tiktok",
          providerAccountId: "demo-tiktok-id",
          accessToken: "demo-tiktok-token",
          refreshToken: "demo-tiktok-refresh",
          expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
          tokenType: "Bearer",
          scope: "user.info.basic,video.upload",
          verified: true,
          channelId: "demo-tiktok-id",
          channelName: "Demo TikTok Account",
        });
      }

      // Create demo sample channel and videos
      const existingChannel = await storage.getChannelByChannelId("UCXuqSBlHAE6Xw0eLa1Uia2w");
      if (!existingChannel) {
        const channel = await storage.createChannel({
          userId: user.id,
          channelId: "UCXuqSBlHAE6Xw0eLa1Uia2w",
          channelName: "Linus Tech Tips",
          channelUrl: "https://www.youtube.com/@LinusTechTips",
          avatar: "https://yt3.ggpht.com/ytc/AL5GRJWBo1JZmX6p8FP9qVd8GXfKJxGdKAg6JKX6KcBl=s240-c-k-c0x00ffffff-no-rj",
          subscriberCount: "15.6M subscribers",
          videoCount: 5,
        });

        // Add some demo videos
        const demoVideos = [
          {
            videoId: "dQw4w9WgXcQ",
            title: "The Future of AI in Tech - What You Need to Know",
            description: "Exploring the latest AI developments and their impact on technology",
            thumbnail: "https://i.ytimg.com/vi/dQw4w9WgXcQ/mqdefault.jpg",
            duration: "12:34",
            publishedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
            viewCount: "1.2M",
            tags: ["tech", "ai", "future", "technology"]
          },
          {
            videoId: "oHg5SJYRHA0",
            title: "Building the Ultimate Gaming Setup in 2024",
            description: "Complete guide to building a high-end gaming PC setup",
            thumbnail: "https://i.ytimg.com/vi/oHg5SJYRHA0/mqdefault.jpg",
            duration: "18:45",
            publishedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
            viewCount: "892K",
            tags: ["gaming", "pc", "setup", "build"]
          },
          {
            videoId: "9bZkp7q19f0",
            title: "iPhone 15 vs Android: The Ultimate Comparison",
            description: "Comprehensive comparison between iPhone 15 and top Android phones",
            thumbnail: "https://i.ytimg.com/vi/9bZkp7q19f0/mqdefault.jpg",
            duration: "15:22",
            publishedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
            viewCount: "2.1M",
            tags: ["iphone", "android", "comparison", "mobile"]
          }
        ];

        for (const video of demoVideos) {
          await storage.createVideo({
            videoId: video.videoId,
            channelId: channel.channelId,
            title: video.title,
            description: video.description,
            thumbnail: video.thumbnail,
            duration: video.duration,
            publishedAt: video.publishedAt,
            viewCount: video.viewCount,
            tags: video.tags,
          });
        }
      }

      // Create session
      const sessionId = randomUUID();
      sessions.set(sessionId, {
        userId: user.id,
        expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days
      });

      res.json({ sessionId, user });
    } catch (error) {
      res.status(400).json({ error: (error as Error).message });
    }
  });

  // Auth routes
  app.get("/api/auth/youtube", (req, res) => {
    const state = randomUUID();
    const authUrl = authService.getYouTubeAuthUrl(state);
    res.json({ authUrl, state });
  });

  app.get("/api/auth/tiktok", (req, res) => {
    const state = randomUUID();
    const authUrl = authService.getTikTokAuthUrl(state);
    res.json({ authUrl, state });
  });

  app.post("/api/auth/youtube/callback", async (req, res) => {
    try {
      const { code, email } = req.body;
      
      const { accessToken, refreshToken, expiresIn, userInfo } = await authService.exchangeYouTubeCode(code);
      
      // Create or get user
      let user = await storage.getUserByEmail(email || userInfo.email);
      if (!user) {
        user = await storage.createUser({
          email: email || userInfo.email,
          name: userInfo.name || "YouTube User",
        });
      }

      // Create or update YouTube account
      const existingAccount = await storage.getAccountByProvider(user.id, "youtube");
      if (existingAccount) {
        await storage.updateAccount(existingAccount.id, {
          accessToken,
          refreshToken,
          expiresAt: new Date(Date.now() + expiresIn * 1000),
          verified: true,
        });
      } else {
        await storage.createAccount({
          userId: user.id,
          provider: "youtube",
          providerAccountId: userInfo.id,
          accessToken,
          refreshToken,
          expiresAt: new Date(Date.now() + expiresIn * 1000),
          tokenType: "Bearer",
          scope: "youtube.upload youtube.readonly",
          verified: true,
        });
      }

      // Create session
      const sessionId = randomUUID();
      sessions.set(sessionId, {
        userId: user.id,
        expiresAt: Date.now() + 30 * 24 * 60 * 60 * 1000, // 30 days
      });

      res.json({ sessionId, user });
    } catch (error) {
      res.status(400).json({ error: (error as Error).message });
    }
  });

  app.post("/api/auth/tiktok/callback", async (req, res) => {
    try {
      const { code, userId } = req.body;
      
      const { accessToken, refreshToken, expiresIn, userInfo } = await authService.exchangeTikTokCode(code);
      
      // Create or update TikTok account
      const existingAccount = await storage.getAccountByProvider(userId, "tiktok");
      if (existingAccount) {
        await storage.updateAccount(existingAccount.id, {
          accessToken,
          refreshToken,
          expiresAt: new Date(Date.now() + expiresIn * 1000),
          verified: true,
          channelId: userInfo?.open_id,
          channelName: userInfo?.display_name,
        });
      } else {
        await storage.createAccount({
          userId,
          provider: "tiktok",
          providerAccountId: userInfo?.open_id || "",
          accessToken,
          refreshToken,
          expiresAt: new Date(Date.now() + expiresIn * 1000),
          tokenType: "Bearer",
          scope: "user.info.basic,video.upload",
          verified: true,
          channelId: userInfo?.open_id,
          channelName: userInfo?.display_name,
        });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: (error as Error).message });
    }
  });

  // Protected routes
  app.get("/api/user", authMiddleware, async (req: AuthenticatedRequest, res) => {
    const user = await storage.getUser(req.userId!);
    const accounts = await storage.getAccountsByUserId(req.userId!);
    
    res.json({
      user,
      accounts: accounts.map(acc => ({
        id: acc.id,
        provider: acc.provider,
        verified: acc.verified,
        channelId: acc.channelId,
        channelName: acc.channelName,
      })),
    });
  });

  app.post("/api/channels", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const { channelUrl } = insertChannelSchema.parse(req.body);
      
      const channelInfo = await youtubeService.getChannelInfo(channelUrl);
      
      // Check if channel already exists
      const existingChannel = await storage.getChannelByChannelId(channelInfo.channelId);
      if (existingChannel) {
        return res.status(400).json({ error: "Channel already tracked" });
      }

      const channel = await storage.createChannel({
        userId: req.userId!,
        channelId: channelInfo.channelId,
        channelName: channelInfo.title,
        channelUrl,
        avatar: channelInfo.thumbnail,
        subscriberCount: channelInfo.subscriberCount,
      });

      // Fetch and store videos
      const videos = await youtubeService.getChannelVideos(channelInfo.channelId);
      
      for (const video of videos) {
        await storage.createVideo({
          videoId: video.videoId,
          channelId: channelInfo.channelId,
          title: video.title,
          description: video.description,
          thumbnail: video.thumbnail,
          duration: video.duration,
          publishedAt: video.publishedAt,
          viewCount: video.viewCount,
          tags: video.tags,
        });
      }

      await storage.updateVideoCount(channelInfo.channelId, videos.length);

      res.json(channel);
    } catch (error) {
      res.status(400).json({ error: (error as Error).message });
    }
  });

  app.get("/api/channels", authMiddleware, async (req: AuthenticatedRequest, res) => {
    const channels = await storage.getChannelsByUserId(req.userId!);
    res.json(channels);
  });

  app.delete("/api/channels/:id", authMiddleware, async (req: AuthenticatedRequest, res) => {
    const success = await storage.deleteChannel(req.params.id);
    res.json({ success });
  });

  app.get("/api/videos", authMiddleware, async (req: AuthenticatedRequest, res) => {
    const channels = await storage.getChannelsByUserId(req.userId!);
    const channelIds = channels.map(c => c.channelId);
    const videos = await storage.getVideosByChannelIds(channelIds);
    res.json(videos);
  });

  app.post("/api/jobs", authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const { videoId } = req.body;
      
      const video = await storage.getVideoByVideoId(videoId);
      if (!video) {
        return res.status(404).json({ error: "Video not found" });
      }

      const job = await queueService.addJob(req.userId!, videoId, video.title);
      res.json(job);
    } catch (error) {
      res.status(400).json({ error: (error as Error).message });
    }
  });

  app.get("/api/jobs", authMiddleware, async (req: AuthenticatedRequest, res) => {
    const jobs = await storage.getJobsByUserId(req.userId!);
    res.json(jobs);
  });

  app.get("/api/jobs/active", authMiddleware, async (req: AuthenticatedRequest, res) => {
    const jobs = await queueService.getActiveJobs();
    const userJobs = jobs.filter(job => job.userId === req.userId);
    res.json(userJobs);
  });

  app.get("/api/queue/status", authMiddleware, (req, res) => {
    const status = queueService.getQueueStatus();
    res.json(status);
  });

  const httpServer = createServer(app);
  return httpServer;
}
