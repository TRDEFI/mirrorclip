import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface SEOContent {
  youtubeTitle: string;
  tiktokCaption: string;
  hashtags: string[];
}

export async function generateSEOContent(
  originalTitle: string,
  description: string,
  tags: string[] = []
): Promise<SEOContent> {
  try {
    const prompt = `Create optimized content for a YouTube video being converted to Shorts and TikTok:

Original Title: "${originalTitle}"
Description: "${description}"
Tags: ${tags.join(", ")}

Generate:
1. A YouTube Shorts title (60-70 characters, engaging, clickbait-friendly)
2. A TikTok caption (100-150 characters, trendy, emoji-friendly) 
3. 3-5 relevant hashtags (trending, niche-specific)

Make the content viral-friendly while maintaining the core message. Use trending language and format.`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "object",
          properties: {
            youtubeTitle: { type: "string" },
            tiktokCaption: { type: "string" },
            hashtags: {
              type: "array",
              items: { type: "string" }
            }
          },
          required: ["youtubeTitle", "tiktokCaption", "hashtags"]
        }
      },
      contents: prompt,
    });

    const rawJson = response.text;

    if (rawJson) {
      const data: SEOContent = JSON.parse(rawJson);
      return data;
    } else {
      throw new Error("Empty response from Gemini");
    }
  } catch (error) {
    console.error("Gemini API error:", error);
    // Fallback content
    return {
      youtubeTitle: originalTitle.substring(0, 70),
      tiktokCaption: `${originalTitle.substring(0, 100)}... #trending #viral`,
      hashtags: ["#viral", "#trending", "#shorts", "#fyp", "#tech"]
    };
  }
}
