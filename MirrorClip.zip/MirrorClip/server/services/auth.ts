import { storage } from "../storage";

interface OAuthConfig {
  clientId: string;
  clientSecret: string;
  redirectUri: string;
}

export class AuthService {
  private youtubeConfig: OAuthConfig;
  private tiktokConfig: OAuthConfig;

  constructor() {
    this.youtubeConfig = {
      clientId: process.env.GOOGLE_CLIENT_ID || "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
      redirectUri: process.env.GOOGLE_REDIRECT_URI || "",
    };

    this.tiktokConfig = {
      clientId: process.env.TIKTOK_CLIENT_ID || "",
      clientSecret: process.env.TIKTOK_CLIENT_SECRET || "",
      redirectUri: process.env.TIKTOK_REDIRECT_URI || "",
    };
  }

  getYouTubeAuthUrl(state: string): string {
    const params = new URLSearchParams({
      client_id: this.youtubeConfig.clientId,
      redirect_uri: this.youtubeConfig.redirectUri,
      response_type: "code",
      scope: "openid email profile https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly",
      access_type: "offline",
      prompt: "consent",
      state,
    });

    return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
  }

  getTikTokAuthUrl(state: string): string {
    const params = new URLSearchParams({
      client_key: this.tiktokConfig.clientId,
      redirect_uri: this.tiktokConfig.redirectUri,
      response_type: "code",
      scope: "user.info.basic,video.upload",
      state,
    });

    return `https://www.tiktok.com/v2/auth/authorize/?${params.toString()}`;
  }

  async exchangeYouTubeCode(code: string): Promise<{
    accessToken: string;
    refreshToken: string;
    expiresIn: number;
    userInfo: any;
  }> {
    const tokenResponse = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: this.youtubeConfig.clientId,
        client_secret: this.youtubeConfig.clientSecret,
        code,
        grant_type: "authorization_code",
        redirect_uri: this.youtubeConfig.redirectUri,
      }),
    });

    const tokenData = await tokenResponse.json();
    
    if (!tokenResponse.ok) {
      throw new Error(`YouTube OAuth error: ${tokenData.error_description}`);
    }

    // Get user info
    const userResponse = await fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });

    const userInfo = await userResponse.json();

    return {
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token,
      expiresIn: tokenData.expires_in,
      userInfo,
    };
  }

  async exchangeTikTokCode(code: string): Promise<{
    accessToken: string;
    refreshToken: string;
    expiresIn: number;
    userInfo: any;
  }> {
    const tokenResponse = await fetch("https://open.tiktokapis.com/v2/oauth/token/", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_key: this.tiktokConfig.clientId,
        client_secret: this.tiktokConfig.clientSecret,
        code,
        grant_type: "authorization_code",
        redirect_uri: this.tiktokConfig.redirectUri,
      }),
    });

    const tokenData = await tokenResponse.json();
    
    if (!tokenResponse.ok) {
      throw new Error(`TikTok OAuth error: ${tokenData.error_description}`);
    }

    // Get user info
    const userResponse = await fetch("https://open.tiktokapis.com/v2/user/info/", {
      method: "POST",
      headers: { 
        Authorization: `Bearer ${tokenData.access_token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ fields: ["open_id", "username", "display_name"] }),
    });

    const userInfo = await userResponse.json();

    return {
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token,
      expiresIn: tokenData.expires_in,
      userInfo: userInfo.data?.user,
    };
  }
}

export const authService = new AuthService();
