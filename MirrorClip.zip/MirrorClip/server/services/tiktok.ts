export class TikTokService {
  async uploadToTikTok(
    accessToken: string,
    videoBuffer: Buffer,
    caption: string
  ): Promise<{ success: boolean; url?: string; error?: string }> {
    try {
      // Step 1: Initialize upload
      const initResponse = await fetch("https://open.tiktokapis.com/v2/post/publish/video/init/", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          post_info: {
            title: caption,
            privacy_level: "MUTUAL_FOLLOW_FRIENDS",
            disable_duet: false,
            disable_comment: false,
            disable_stitch: false,
            video_cover_timestamp_ms: 1000,
          },
          source_info: {
            source: "FILE_UPLOAD",
            video_size: videoBuffer.length,
            chunk_size: videoBuffer.length,
            total_chunk_count: 1,
          },
        }),
      });

      const initData = await initResponse.json();

      if (!initResponse.ok) {
        return { success: false, error: initData.error?.message || "Upload initialization failed" };
      }

      // Step 2: Upload video
      const uploadUrl = initData.data.upload_url;
      const publishId = initData.data.publish_id;

      const uploadResponse = await fetch(uploadUrl, {
        method: "PUT",
        headers: {
          "Content-Type": "video/mp4",
          "Content-Range": `bytes 0-${videoBuffer.length - 1}/${videoBuffer.length}`,
        },
        body: videoBuffer,
      });

      if (!uploadResponse.ok) {
        return { success: false, error: "Video upload failed" };
      }

      // Step 3: Publish video
      const publishResponse = await fetch("https://open.tiktokapis.com/v2/post/publish/", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          publish_id: publishId,
        }),
      });

      const publishData = await publishResponse.json();

      if (!publishResponse.ok) {
        return { success: false, error: publishData.error?.message || "Video publish failed" };
      }

      return {
        success: true,
        url: `https://www.tiktok.com/@user/video/${publishData.data.share_id}`,
      };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }
}

export const tiktokService = new TikTokService();
