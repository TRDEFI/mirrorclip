import { storage } from "../storage";
import { Job } from "@shared/schema";

interface QueueJob {
  id: string;
  userId: string;
  videoId: string;
  priority: number;
}

export class QueueService {
  private queue: QueueJob[] = [];
  private processing: Set<string> = new Set();

  async addJob(userId: string, videoId: string, originalTitle: string): Promise<Job> {
    const job = await storage.createJob({
      userId,
      videoId,
      status: "queued",
      progress: 0,
      originalTitle,
    });

    this.queue.push({
      id: job.id,
      userId,
      videoId,
      priority: Date.now(),
    });

    this.queue.sort((a, b) => a.priority - b.priority);

    // Start processing if not already running
    setImmediate(() => this.processNext());

    return job;
  }

  async getActiveJobs(): Promise<Job[]> {
    return storage.getActiveJobs();
  }

  private async processNext(): Promise<void> {
    if (this.queue.length === 0 || this.processing.size >= 3) {
      return; // No jobs or max concurrent jobs reached
    }

    const queueJob = this.queue.shift();
    if (!queueJob) return;

    this.processing.add(queueJob.id);

    try {
      // Import video processor here to avoid circular dependencies
      const { processVideo } = await import("./video-processor");
      await processVideo(queueJob.id);
    } catch (error) {
      console.error(`Job ${queueJob.id} failed:`, error);
      await storage.updateJob(queueJob.id, {
        status: "failed",
        error: (error as Error).message,
      });
    } finally {
      this.processing.delete(queueJob.id);
      // Process next job
      setImmediate(() => this.processNext());
    }
  }

  getQueueStatus(): { queued: number; processing: number } {
    return {
      queued: this.queue.length,
      processing: this.processing.size,
    };
  }
}

export const queueService = new QueueService();
