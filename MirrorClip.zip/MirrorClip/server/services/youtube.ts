export class YouTubeService {
  private apiKey: string;

  constructor() {
    this.apiKey = process.env.YOUTUBE_API_KEY || "";
  }

  async getChannelInfo(channelUrl: string): Promise<{
    channelId: string;
    title: string;
    description: string;
    thumbnail: string;
    subscriberCount: string;
  }> {
    let channelId = "";
    
    // Extract channel ID from various URL formats
    if (channelUrl.includes("/@")) {
      const handle = channelUrl.split("/@")[1];
      const searchResponse = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&q=${handle}&key=${this.apiKey}`
      );
      const searchData = await searchResponse.json();
      
      if (searchData.items && searchData.items.length > 0) {
        channelId = searchData.items[0].snippet.channelId;
      }
    } else if (channelUrl.includes("/channel/")) {
      channelId = channelUrl.split("/channel/")[1];
    } else if (channelUrl.match(/^UC[A-Za-z0-9_-]{22}$/)) {
      channelId = channelUrl;
    }

    if (!channelId) {
      throw new Error("Could not extract channel ID from URL");
    }

    const response = await fetch(
      `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id=${channelId}&key=${this.apiKey}`
    );

    const data = await response.json();

    if (!response.ok || !data.items || data.items.length === 0) {
      throw new Error("Channel not found");
    }

    const channel = data.items[0];

    return {
      channelId,
      title: channel.snippet.title,
      description: channel.snippet.description,
      thumbnail: channel.snippet.thumbnails.medium.url,
      subscriberCount: this.formatSubscriberCount(channel.statistics.subscriberCount),
    };
  }

  async getChannelVideos(channelId: string, maxResults: number = 50): Promise<Array<{
    videoId: string;
    title: string;
    description: string;
    thumbnail: string;
    duration: string;
    publishedAt: Date;
    viewCount: string;
    tags?: string[];
  }>> {
    const response = await fetch(
      `https://www.googleapis.com/youtube/v3/search?part=snippet&channelId=${channelId}&order=date&maxResults=${maxResults}&type=video&key=${this.apiKey}`
    );

    const data = await response.json();

    if (!response.ok) {
      throw new Error("Failed to fetch channel videos");
    }

    const videoIds = data.items.map((item: any) => item.id.videoId).join(",");
    
    // Get additional video details
    const detailsResponse = await fetch(
      `https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics,snippet&id=${videoIds}&key=${this.apiKey}`
    );

    const detailsData = await detailsResponse.json();

    return detailsData.items.map((item: any) => ({
      videoId: item.id,
      title: item.snippet.title,
      description: item.snippet.description,
      thumbnail: item.snippet.thumbnails.medium.url,
      duration: this.formatDuration(item.contentDetails.duration),
      publishedAt: new Date(item.snippet.publishedAt),
      viewCount: this.formatViewCount(item.statistics.viewCount),
      tags: item.snippet.tags,
    }));
  }

  async uploadToYouTubeShorts(
    accessToken: string,
    videoBuffer: Buffer,
    title: string,
    description: string,
    tags: string[]
  ): Promise<{ success: boolean; url?: string; error?: string }> {
    try {
      const formData = new FormData();
      const videoBlob = new Blob([videoBuffer], { type: "video/mp4" });
      
      formData.append("video", videoBlob);
      formData.append("snippet", JSON.stringify({
        title,
        description,
        tags,
        categoryId: "22", // People & Blogs
        defaultLanguage: "en",
      }));
      formData.append("status", JSON.stringify({
        privacyStatus: "public",
        selfDeclaredMadeForKids: false,
      }));

      const response = await fetch(
        "https://www.googleapis.com/upload/youtube/v3/videos?part=snippet,status",
        {
          method: "POST",
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
          body: formData,
        }
      );

      const result = await response.json();

      if (!response.ok) {
        return { success: false, error: result.error?.message || "Upload failed" };
      }

      return {
        success: true,
        url: `https://www.youtube.com/watch?v=${result.id}`,
      };
    } catch (error) {
      return { success: false, error: (error as Error).message };
    }
  }

  private formatDuration(isoDuration: string): string {
    const match = isoDuration.match(/PT(\d+H)?(\d+M)?(\d+S)?/);
    if (!match) return "0:00";

    const hours = match[1] ? parseInt(match[1]) : 0;
    const minutes = match[2] ? parseInt(match[2]) : 0;
    const seconds = match[3] ? parseInt(match[3]) : 0;

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
    }
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  }

  private formatViewCount(count: string): string {
    const num = parseInt(count);
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return count;
  }

  private formatSubscriberCount(count: string): string {
    const num = parseInt(count);
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M subscribers`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K subscribers`;
    }
    return `${count} subscribers`;
  }
}

export const youtubeService = new YouTubeService();
