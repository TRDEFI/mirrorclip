import { users, accounts, channels, videos, jobs, type User, type InsertUser, type Account, type InsertAccount, type Channel, type InsertChannel, type Video, type InsertVideo, type Job, type InsertJob } from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, inArray } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Accounts
  getAccountsByUserId(userId: string): Promise<Account[]>;
  getAccountByProvider(userId: string, provider: string): Promise<Account | undefined>;
  createAccount(account: InsertAccount): Promise<Account>;
  updateAccount(id: string, updates: Partial<Account>): Promise<Account | undefined>;
  deleteAccount(id: string): Promise<boolean>;

  // Channels
  getChannelsByUserId(userId: string): Promise<Channel[]>;
  getChannelByChannelId(channelId: string): Promise<Channel | undefined>;
  createChannel(channel: InsertChannel): Promise<Channel>;
  deleteChannel(id: string): Promise<boolean>;

  // Videos
  getVideosByChannelIds(channelIds: string[]): Promise<Video[]>;
  getVideoByVideoId(videoId: string): Promise<Video | undefined>;
  createVideo(video: InsertVideo): Promise<Video>;
  updateVideoCount(channelId: string, count: number): Promise<void>;

  // Jobs
  getJobsByUserId(userId: string): Promise<Job[]>;
  getActiveJobs(): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: string, updates: Partial<Job>): Promise<Job | undefined>;
}

export class DatabaseStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private accounts: Map<string, Account> = new Map();
  private channels: Map<string, Channel> = new Map();
  private videos: Map<string, Video> = new Map();
  private jobs: Map<string, Job> = new Map();

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async getAccountsByUserId(userId: string): Promise<Account[]> {
    return Array.from(this.accounts.values()).filter(account => account.userId === userId);
  }

  async getAccountByProvider(userId: string, provider: string): Promise<Account | undefined> {
    return Array.from(this.accounts.values()).find(
      account => account.userId === userId && account.provider === provider
    );
  }

  async createAccount(insertAccount: InsertAccount): Promise<Account> {
    const id = randomUUID();
    const account: Account = { 
      ...insertAccount,
      accessToken: insertAccount.accessToken || null,
      refreshToken: insertAccount.refreshToken || null,
      expiresAt: insertAccount.expiresAt || null,
      tokenType: insertAccount.tokenType || null,
      scope: insertAccount.scope || null,
      channelId: insertAccount.channelId || null,
      channelName: insertAccount.channelName || null,
      verified: insertAccount.verified || false,
      id, 
      createdAt: new Date()
    };
    this.accounts.set(id, account);
    return account;
  }

  async updateAccount(id: string, updates: Partial<Account>): Promise<Account | undefined> {
    const account = this.accounts.get(id);
    if (!account) return undefined;
    
    const updated = { ...account, ...updates };
    this.accounts.set(id, updated);
    return updated;
  }

  async deleteAccount(id: string): Promise<boolean> {
    return this.accounts.delete(id);
  }

  async getChannelsByUserId(userId: string): Promise<Channel[]> {
    return Array.from(this.channels.values()).filter(
      channel => channel.userId === userId && channel.isActive
    );
  }

  async getChannelByChannelId(channelId: string): Promise<Channel | undefined> {
    return Array.from(this.channels.values()).find(
      channel => channel.channelId === channelId
    );
  }

  async createChannel(insertChannel: InsertChannel): Promise<Channel> {
    const id = randomUUID();
    const channel: Channel = { 
      ...insertChannel,
      avatar: insertChannel.avatar || null,
      subscriberCount: insertChannel.subscriberCount || null,
      videoCount: insertChannel.videoCount || 0,
      isActive: insertChannel.isActive !== false,
      id, 
      createdAt: new Date()
    };
    this.channels.set(id, channel);
    return channel;
  }

  async deleteChannel(id: string): Promise<boolean> {
    const channel = this.channels.get(id);
    if (channel) {
      const updated = { ...channel, isActive: false };
      this.channels.set(id, updated);
      return true;
    }
    return false;
  }

  async getVideosByChannelIds(channelIds: string[]): Promise<Video[]> {
    return Array.from(this.videos.values()).filter(
      video => channelIds.includes(video.channelId)
    ).sort((a, b) => (b.publishedAt?.getTime() || 0) - (a.publishedAt?.getTime() || 0));
  }

  async getVideoByVideoId(videoId: string): Promise<Video | undefined> {
    return Array.from(this.videos.values()).find(video => video.videoId === videoId);
  }

  async createVideo(insertVideo: InsertVideo): Promise<Video> {
    const id = randomUUID();
    const video: Video = { 
      ...insertVideo,
      description: insertVideo.description || null,
      thumbnail: insertVideo.thumbnail || null,
      duration: insertVideo.duration || null,
      publishedAt: insertVideo.publishedAt || null,
      viewCount: insertVideo.viewCount || null,
      tags: Array.isArray(insertVideo.tags) ? insertVideo.tags : null,
      id, 
      createdAt: new Date()
    };
    this.videos.set(id, video);
    return video;
  }

  async updateVideoCount(channelId: string, count: number): Promise<void> {
    const channel = Array.from(this.channels.values()).find(c => c.channelId === channelId);
    if (channel) {
      const updated = { ...channel, videoCount: count };
      this.channels.set(channel.id, updated);
    }
  }

  async getJobsByUserId(userId: string): Promise<Job[]> {
    return Array.from(this.jobs.values())
      .filter(job => job.userId === userId)
      .sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
  }

  async getActiveJobs(): Promise<Job[]> {
    return Array.from(this.jobs.values()).filter(
      job => ['queued', 'downloading', 'generating', 'uploading'].includes(job.status)
    );
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = randomUUID();
    const job: Job = { 
      ...insertJob,
      progress: insertJob.progress || 0,
      originalTitle: insertJob.originalTitle || null,
      generatedContent: insertJob.generatedContent ? {
        youtubeTitle: insertJob.generatedContent.youtubeTitle,
        tiktokCaption: insertJob.generatedContent.tiktokCaption,
        hashtags: insertJob.generatedContent.hashtags
      } : null,
      uploadResults: insertJob.uploadResults ? {
        youtube: insertJob.uploadResults.youtube,
        tiktok: insertJob.uploadResults.tiktok
      } : null,
      error: insertJob.error || null,
      id, 
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.jobs.set(id, job);
    return job;
  }

  async updateJob(id: string, updates: Partial<Job>): Promise<Job | undefined> {
    const job = this.jobs.get(id);
    if (!job) return undefined;
    
    const updated = { ...job, ...updates, updatedAt: new Date() };
    this.jobs.set(id, updated);
    return updated;
  }
}

export const storage = new DatabaseStorage();
