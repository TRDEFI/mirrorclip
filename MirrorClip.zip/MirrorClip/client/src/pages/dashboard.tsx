import { useQuery } from "@tanstack/react-query";
import Navigation from "@/components/ui/navigation";
import AccountConnections from "@/components/account-connections";
import ChannelInput from "@/components/channel-input";
import VideoGrid from "@/components/video-grid";
import ProcessingQueue from "@/components/processing-queue";
import MirrorModal from "@/components/mirror-modal";
import { useState } from "react";

export default function Dashboard() {
  const [selectedVideo, setSelectedVideo] = useState<any>(null);
  const [showMirrorModal, setShowMirrorModal] = useState(false);

  const { data: userData } = useQuery({
    queryKey: ["/api/user"],
  });

  const { data: queueStatus } = useQuery({
    queryKey: ["/api/queue/status"],
    refetchInterval: 5000,
  });

  const handleMirrorVideo = (video: any) => {
    setSelectedVideo(video);
    setShowMirrorModal(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation queuedJobs={(queueStatus as any)?.queued || 0} />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AccountConnections accounts={(userData as any)?.accounts || []} />
        <ChannelInput />
        <VideoGrid onMirrorVideo={handleMirrorVideo} />
        <ProcessingQueue />
      </div>

      <MirrorModal
        video={selectedVideo}
        isOpen={showMirrorModal}
        onClose={() => setShowMirrorModal(false)}
        accounts={(userData as any)?.accounts || []}
      />
    </div>
  );
}
