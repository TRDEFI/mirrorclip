import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { RefreshCw, Eye, Play } from "lucide-react";

interface Video {
  id: string;
  videoId: string;
  title: string;
  thumbnail: string;
  duration: string;
  publishedAt: string;
  viewCount: string;
  channelId: string;
}

interface VideoGridProps {
  onMirrorVideo: (video: Video) => void;
}

export default function VideoGrid({ onMirrorVideo }: VideoGridProps) {
  const [sortBy, setSortBy] = useState("latest");

  const { data: videos, isLoading, refetch } = useQuery({
    queryKey: ["/api/videos"],
  });

  const { data: activeJobs } = useQuery({
    queryKey: ["/api/jobs/active"],
    refetchInterval: 5000,
  });

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return "Just now";
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays} days ago`;
    
    const diffInWeeks = Math.floor(diffInDays / 7);
    return `${diffInWeeks} weeks ago`;
  };

  const isVideoQueued = (videoId: string) => {
    return Array.isArray(activeJobs) && activeJobs.some((job: any) => job.videoId === videoId && ['queued', 'downloading', 'generating', 'uploading'].includes(job.status));
  };

  const getJobStatus = (videoId: string) => {
    const job = Array.isArray(activeJobs) && activeJobs.find((job: any) => job.videoId === videoId);
    if (!job) return null;
    
    const statusMap: Record<string, string> = {
      queued: "Queued",
      downloading: "Downloading",
      generating: "Generating",
      uploading: "Uploading",
    };
    
    return statusMap[job.status] || job.status;
  };

  if (!videos || !Array.isArray(videos) || videos.length === 0) {
    return (
      <div className="mb-8">
        <Card>
          <CardContent className="p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Available Videos</h2>
            <div className="text-center py-12">
              <p className="text-gray-500">No videos available. Add a channel to get started.</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="mb-8">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Available Videos</h2>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm text-gray-600">Sort by:</label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="latest">Latest</SelectItem>
                    <SelectItem value="views">Most Views</SelectItem>
                    <SelectItem value="duration">Duration</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => refetch()}
                disabled={isLoading}
              >
                <RefreshCw className={`w-4 h-4 mr-1 ${isLoading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {videos.map((video: Video) => {
              const queued = isVideoQueued(video.videoId);
              const status = getJobStatus(video.videoId);
              
              return (
                <div key={video.id} className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-md transition-shadow">
                  <div className="relative">
                    <img 
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white text-xs px-2 py-1 rounded">
                      {video.duration}
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-medium text-gray-900 text-sm leading-5 mb-2 line-clamp-2">
                      {video.title}
                    </h3>
                    <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                      <span>{formatTimeAgo(video.publishedAt)}</span>
                      <span>{video.viewCount} views</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      {queued ? (
                        <Button 
                          disabled
                          className="flex-1 bg-warning text-white cursor-not-allowed opacity-75"
                          size="sm"
                        >
                          <RefreshCw className="w-4 h-4 mr-1 animate-spin" />
                          {status}
                        </Button>
                      ) : (
                        <Button 
                          onClick={() => onMirrorVideo(video)}
                          className="flex-1"
                          size="sm"
                        >
                          <Play className="w-4 h-4 mr-1" />
                          Mirror
                        </Button>
                      )}
                      <Button 
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(`https://www.youtube.com/watch?v=${video.videoId}`, '_blank')}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-6 flex justify-center">
            <Button variant="ghost">
              Load More Videos
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
