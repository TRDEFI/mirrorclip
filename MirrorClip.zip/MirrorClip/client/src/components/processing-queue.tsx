import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Download, Wand2, Clock, CheckCircle, XCircle, Plus, ExternalLink } from "lucide-react";

export default function ProcessingQueue() {
  const { data: activeJobs } = useQuery({
    queryKey: ["/api/jobs/active"],
    refetchInterval: 2000,
  });

  const { data: recentJobs } = useQuery({
    queryKey: ["/api/jobs"],
    refetchInterval: 10000,
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'downloading':
        return <Download className="w-5 h-5 text-primary" />;
      case 'generating':
        return <Wand2 className="w-5 h-5 text-warning" />;
      case 'uploading':
        return <Download className="w-5 h-5 text-primary" />;
      case 'queued':
        return <Clock className="w-5 h-5 text-gray-500" />;
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-success" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-error" />;
      default:
        return <Clock className="w-5 h-5 text-gray-500" />;
    }
  };

  const getStatusDescription = (status: string) => {
    switch (status) {
      case 'downloading':
        return 'Downloading from YouTube';
      case 'generating':
        return 'Creating optimized titles and captions';
      case 'uploading':
        return 'Uploading to platforms';
      case 'queued':
        return 'Waiting in queue';
      case 'completed':
        return 'Successfully uploaded';
      case 'failed':
        return 'Upload failed';
      default:
        return status;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'downloading':
      case 'uploading':
        return 'bg-blue-50 border-blue-200';
      case 'generating':
        return 'bg-yellow-50 border-yellow-200';
      case 'queued':
        return 'bg-gray-50 border-gray-200';
      case 'completed':
        return 'bg-green-50 border-green-200';
      case 'failed':
        return 'bg-red-50 border-red-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "Just now";
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays} days ago`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Processing Queue</h2>
          
          {activeJobs && Array.isArray(activeJobs) && activeJobs.length > 0 ? (
            <div className="space-y-4">
              {activeJobs.map((job: any) => (
                <div key={job.id} className={`flex items-center justify-between p-4 rounded-lg border ${getStatusColor(job.status)}`}>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                      {getStatusIcon(job.status)}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900 text-sm">
                        {job.status === 'downloading' ? 'Downloading: ' : 
                         job.status === 'generating' ? 'Generating SEO: ' : 
                         job.status === 'uploading' ? 'Uploading: ' : ''}
                        {job.originalTitle?.substring(0, 30)}...
                      </p>
                      <p className="text-xs text-gray-600">{getStatusDescription(job.status)}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    {job.status === 'queued' ? (
                      <span className="text-xs text-gray-500">#1 in queue</span>
                    ) : job.progress ? (
                      <>
                        <div className="w-16 bg-gray-200 rounded-full h-2 mb-1">
                          <div 
                            className="bg-primary h-2 rounded-full transition-all duration-300" 
                            style={{ width: `${job.progress}%` }}
                          ></div>
                        </div>
                        <span className="text-xs text-gray-600">{job.progress}%</span>
                      </>
                    ) : (
                      <div className="animate-spin w-4 h-4 border-2 border-warning border-t-transparent rounded-full"></div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500 text-sm">No active jobs</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h2>
          
          {recentJobs && Array.isArray(recentJobs) && recentJobs.length > 0 ? (
            <div className="space-y-4">
              {recentJobs.slice(0, 5).map((job: any) => (
                <div key={job.id} className="flex items-start space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    job.status === 'completed' ? 'bg-success' : 
                    job.status === 'failed' ? 'bg-error' : 'bg-primary'
                  }`}>
                    {getStatusIcon(job.status)}
                  </div>
                  <div className="flex-1">
                    {job.status === 'completed' ? (
                      <>
                        <p className="text-sm font-medium text-gray-900">
                          Successfully uploaded "{job.originalTitle?.substring(0, 40)}..."
                        </p>
                        <p className="text-xs text-gray-500 mt-1">{formatTimeAgo(job.updatedAt)}</p>
                        {job.uploadResults && (
                          <div className="flex items-center space-x-4 mt-2">
                            {job.uploadResults.youtube?.success && (
                              <Button variant="link" size="sm" className="p-0 h-auto text-xs">
                                <ExternalLink className="w-3 h-3 mr-1" />
                                View on YouTube
                              </Button>
                            )}
                            {job.uploadResults.tiktok?.success && (
                              <Button variant="link" size="sm" className="p-0 h-auto text-xs">
                                <ExternalLink className="w-3 h-3 mr-1" />
                                View on TikTok
                              </Button>
                            )}
                          </div>
                        )}
                      </>
                    ) : job.status === 'failed' ? (
                      <>
                        <p className="text-sm font-medium text-gray-900">
                          Failed to upload "{job.originalTitle?.substring(0, 40)}..." - {job.error}
                        </p>
                        <p className="text-xs text-gray-500 mt-1">{formatTimeAgo(job.updatedAt)}</p>
                        <Button variant="link" size="sm" className="p-0 h-auto text-xs mt-1">
                          Retry Upload
                        </Button>
                      </>
                    ) : (
                      <>
                        <p className="text-sm font-medium text-gray-900">
                          {getStatusDescription(job.status)} - "{job.originalTitle?.substring(0, 40)}..."
                        </p>
                        <p className="text-xs text-gray-500 mt-1">{formatTimeAgo(job.createdAt)}</p>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500 text-sm">No recent activity</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
