import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Plus, X } from "lucide-react";

export default function ChannelInput() {
  const [channelUrl, setChannelUrl] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: channels } = useQuery({
    queryKey: ["/api/channels"],
  });

  const addChannelMutation = useMutation({
    mutationFn: async (channelUrl: string) => {
      const response = await apiRequest('POST', '/api/channels', { channelUrl });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Channel Added",
        description: "Channel has been successfully added and videos are being indexed",
      });
      setChannelUrl("");
      queryClient.invalidateQueries({ queryKey: ["/api/channels"] });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Add Channel",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const removeChannelMutation = useMutation({
    mutationFn: async (channelId: string) => {
      const response = await apiRequest('DELETE', `/api/channels/${channelId}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Channel Removed",
        description: "Channel has been removed from tracking",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/channels"] });
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (channelUrl.trim()) {
      addChannelMutation.mutate(channelUrl.trim());
    }
  };

  return (
    <div className="mb-8">
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Add Source Channel</h2>
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4">
            <Input
              type="url"
              placeholder="https://www.youtube.com/@channelname or Channel ID"
              value={channelUrl}
              onChange={(e) => setChannelUrl(e.target.value)}
              className="flex-1"
              required
            />
            <Button 
              type="submit"
              disabled={addChannelMutation.isPending}
              className="whitespace-nowrap"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Channel
            </Button>
          </form>
          
          {channels && Array.isArray(channels) && channels.length > 0 && (
            <div className="mt-6">
              <h3 className="text-sm font-medium text-gray-700 mb-3">Tracked Channels</h3>
              <div className="space-y-2">
                {channels.map((channel: any) => (
                  <div key={channel.id} className="flex items-center justify-between py-3 px-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      {channel.avatar && (
                        <img 
                          src={channel.avatar}
                          alt={channel.channelName}
                          className="w-10 h-10 rounded-full"
                        />
                      )}
                      <div>
                        <p className="font-medium text-gray-900">{channel.channelName}</p>
                        <p className="text-sm text-gray-500">{channel.subscriberCount}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <span className="text-sm text-gray-600">{channel.videoCount || 0} videos found</span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeChannelMutation.mutate(channel.id)}
                        disabled={removeChannelMutation.isPending}
                        className="text-error hover:text-red-700"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
