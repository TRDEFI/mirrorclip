import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Account {
  id: string;
  provider: string;
  verified: boolean;
  channelId?: string;
  channelName?: string;
}

interface AccountConnectionsProps {
  accounts: Account[];
}

export default function AccountConnections({ accounts }: AccountConnectionsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const youtubeAccount = accounts.find(acc => acc.provider === 'youtube');
  const tiktokAccount = accounts.find(acc => acc.provider === 'tiktok');

  const connectYouTube = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('GET', '/api/auth/youtube');
      const data = await response.json();
      window.location.href = data.authUrl;
    },
    onError: () => {
      toast({
        title: "Connection Failed",
        description: "Failed to initiate YouTube connection",
        variant: "destructive",
      });
    },
  });

  const connectTikTok = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('GET', '/api/auth/tiktok');
      const data = await response.json();
      window.location.href = data.authUrl;
    },
    onError: () => {
      toast({
        title: "Connection Failed",
        description: "Failed to initiate TikTok connection",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="mb-8">
      <Card>
        <CardContent className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Account Connections</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <i className="fab fa-youtube text-red-600 text-xl"></i>
                  <span className="font-medium text-gray-900">YouTube</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${youtubeAccount?.verified ? 'bg-success' : 'bg-gray-300'}`}></div>
                  <span className={`text-sm font-medium ${youtubeAccount?.verified ? 'text-success' : 'text-gray-500'}`}>
                    {youtubeAccount?.verified ? 'Connected' : 'Not Connected'}
                  </span>
                </div>
              </div>
              {youtubeAccount?.verified ? (
                <p className="text-sm text-gray-600 mb-3">{youtubeAccount.channelName || 'YouTube Account'}</p>
              ) : (
                <p className="text-sm text-gray-600 mb-3">Connect your YouTube account to upload Shorts</p>
              )}
              {!youtubeAccount?.verified && (
                <Button
                  onClick={() => connectYouTube.mutate()}
                  disabled={connectYouTube.isPending}
                  className="bg-red-600 hover:bg-red-700 text-white"
                  size="sm"
                >
                  Connect YouTube
                </Button>
              )}
            </div>

            <div className="border border-gray-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <i className="fab fa-tiktok text-black text-xl"></i>
                  <span className="font-medium text-gray-900">TikTok</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${tiktokAccount?.verified ? 'bg-success' : 'bg-warning'}`}></div>
                  <span className={`text-sm font-medium ${tiktokAccount?.verified ? 'text-success' : 'text-warning'}`}>
                    {tiktokAccount?.verified ? 'Connected' : 'Not Connected'}
                  </span>
                </div>
              </div>
              {tiktokAccount?.verified ? (
                <p className="text-sm text-gray-600 mb-3">{tiktokAccount.channelName || 'TikTok Account'}</p>
              ) : (
                <p className="text-sm text-gray-600 mb-3">Connect your TikTok account to start mirroring</p>
              )}
              {!tiktokAccount?.verified && (
                <Button
                  onClick={() => connectTikTok.mutate()}
                  disabled={connectTikTok.isPending}
                  className="bg-black hover:bg-gray-800 text-white"
                  size="sm"
                >
                  Connect TikTok
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
