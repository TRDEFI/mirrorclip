import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface DemoAuthProps {
  onAuthenticated: (sessionId: string) => void;
}

export default function DemoAuth({ onAuthenticated }: DemoAuthProps) {
  const [email, setEmail] = useState("demo@mirrorclip.com");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const demoLoginMutation = useMutation({
    mutationFn: async (email: string) => {
      const response = await apiRequest('POST', '/api/auth/demo', { email });
      return response.json();
    },
    onSuccess: (data) => {
      localStorage.setItem('sessionId', data.sessionId);
      onAuthenticated(data.sessionId);
      toast({
        title: "Demo Login Successful",
        description: "You can now explore MirrorClip features",
      });
      queryClient.invalidateQueries();
    },
    onError: (error: Error) => {
      toast({
        title: "Demo Login Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      demoLoginMutation.mutate(email.trim());
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-lg">M</span>
            </div>
            <span className="text-2xl font-bold text-gray-900">MirrorClip</span>
          </div>
          <h2 className="text-lg text-gray-600">Auto-Mirror YouTube → Shorts & TikTok</h2>
          <p className="mt-2 text-sm text-gray-500">
            Automatically repurpose YouTube videos into optimized content for YouTube Shorts and TikTok with AI-generated SEO optimization.
          </p>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-center">Demo Access</CardTitle>
            <p className="text-sm text-gray-600 text-center">
              Enter your email to explore MirrorClip features. This demo uses sample data and simulated processing.
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <Input
                type="email"
                placeholder="your.email@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Button 
                type="submit"
                className="w-full"
                disabled={demoLoginMutation.isPending}
              >
                {demoLoginMutation.isPending ? "Starting Demo..." : "Start Demo"}
              </Button>
            </form>
            
            <div className="mt-6 pt-4 border-t border-gray-200">
              <p className="text-xs text-gray-500 text-center">
                Note: This is a demonstration environment. To use real YouTube and TikTok accounts, contact support for OAuth setup.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}