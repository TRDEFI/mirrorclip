import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Video {
  id: string;
  videoId: string;
  title: string;
  channelId: string;
}

interface Account {
  provider: string;
  verified: boolean;
}

interface MirrorModalProps {
  video: Video | null;
  isOpen: boolean;
  onClose: () => void;
  accounts: Account[];
}

export default function MirrorModal({ video, isOpen, onClose, accounts }: MirrorModalProps) {
  const [uploadToYoutube, setUploadToYoutube] = useState(true);
  const [uploadToTiktok, setUploadToTiktok] = useState(true);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const youtubeConnected = accounts.find(acc => acc.provider === 'youtube')?.verified;
  const tiktokConnected = accounts.find(acc => acc.provider === 'tiktok')?.verified;

  const startMirrorMutation = useMutation({
    mutationFn: async () => {
      if (!video) throw new Error("No video selected");
      
      const response = await apiRequest('POST', '/api/jobs', {
        videoId: video.videoId,
        platforms: {
          youtube: uploadToYoutube && youtubeConnected,
          tiktok: uploadToTiktok && tiktokConnected,
        }
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Mirror Started",
        description: "Video has been added to the processing queue",
      });
      onClose();
      queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/jobs/active"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to Start Mirror",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleConfirm = () => {
    if (!uploadToYoutube && !uploadToTiktok) {
      toast({
        title: "No Platforms Selected",
        description: "Please select at least one platform to upload to",
        variant: "destructive",
      });
      return;
    }

    if ((uploadToYoutube && !youtubeConnected) || (uploadToTiktok && !tiktokConnected)) {
      toast({
        title: "Account Not Connected",
        description: "Please connect the required accounts first",
        variant: "destructive",
      });
      return;
    }

    startMirrorMutation.mutate();
  };

  if (!video) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Confirm Mirror</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <p className="text-sm text-gray-600">
            This will download the video, generate optimized titles and captions using AI, and upload to your connected platforms.
          </p>
          
          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-sm font-medium text-gray-900 mb-1">{video.title}</p>
            <p className="text-xs text-gray-500">From: YouTube Channel</p>
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-900 mb-2">Upload to:</h4>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="youtube"
                  checked={uploadToYoutube}
                  onCheckedChange={(checked) => setUploadToYoutube(checked === true)}
                  disabled={!youtubeConnected}
                />
                <label htmlFor="youtube" className={`text-sm ${youtubeConnected ? 'text-gray-700' : 'text-gray-400'}`}>
                  YouTube Shorts {!youtubeConnected && '(Not Connected)'}
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="tiktok"
                  checked={uploadToTiktok}
                  onCheckedChange={(checked) => setUploadToTiktok(checked === true)}
                  disabled={!tiktokConnected}
                />
                <label htmlFor="tiktok" className={`text-sm ${tiktokConnected ? 'text-gray-700' : 'text-gray-400'}`}>
                  TikTok {!tiktokConnected && '(Not Connected)'}
                </label>
              </div>
            </div>
          </div>

          <div className="flex space-x-3 pt-4">
            <Button 
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleConfirm}
              disabled={startMirrorMutation.isPending}
              className="flex-1"
            >
              {startMirrorMutation.isPending ? "Starting..." : "Start Mirror"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
