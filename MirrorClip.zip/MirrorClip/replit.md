# MirrorClip - YouTube to Shorts & TikTok Auto-Mirror Tool

## Overview

MirrorClip is a full-stack web application that automates the process of repurposing YouTube videos into optimized content for YouTube Shorts and TikTok. The application allows users to connect their social media accounts, track YouTube channels, and automatically generate SEO-optimized titles and captions using AI before uploading to multiple platforms.

**Current Status**: Complete functional prototype with demo authentication system. Users can explore all features without requiring external OAuth setup.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (January 30, 2025)

✓ **Demo Authentication System**: Implemented complete demo login flow allowing users to test all features
✓ **Database Schema**: Created comprehensive schema for users, accounts, channels, videos, and processing jobs  
✓ **AI Integration**: Integrated Google Gemini API for SEO content generation (titles, captions, hashtags)
✓ **Video Processing Pipeline**: Built queue-based system with real-time status updates
✓ **Frontend Components**: Developed responsive UI with shadcn/ui components and real-time updates
✓ **Sample Data**: Added demo YouTube channel (Linus Tech Tips) with sample videos for testing

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **UI Framework**: Radix UI components with shadcn/ui styling system
- **Styling**: Tailwind CSS with CSS variables for theming
- **State Management**: TanStack Query (React Query) for server state management
- **Build Tool**: Vite for fast development and optimized builds

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **Session Management**: Simple in-memory sessions (production requires proper session store)
- **File Processing**: yt-dlp for video downloading and processing

### Data Storage Solutions
- **Primary Database**: PostgreSQL via Neon Database
- **ORM**: Drizzle ORM with Zod schema validation
- **Storage Interface**: Abstracted storage layer with in-memory fallback for development
- **Session Storage**: In-memory Map (temporary solution)

## Key Components

### Authentication & Authorization
- OAuth 2.0 integration for YouTube (Google) and TikTok
- Simple bearer token session management
- Account linking system for multiple platforms per user

### Video Processing Pipeline
1. **Channel Tracking**: Users add YouTube channels to monitor
2. **Video Discovery**: Automatic fetching of channel videos via YouTube API
3. **Job Queue**: Asynchronous processing system for video mirroring
4. **Content Generation**: AI-powered SEO optimization using Google Gemini API
5. **Multi-platform Upload**: Automated uploads to YouTube Shorts and TikTok

### Core Services
- **Auth Service**: Handles OAuth flows for YouTube and TikTok
- **YouTube Service**: Channel info retrieval and Shorts uploading
- **TikTok Service**: Video uploads to TikTok platform
- **Gemini Service**: AI content generation for titles and captions
- **Queue Service**: Job management and processing coordination
- **Video Processor**: Orchestrates the entire mirroring workflow

### Database Schema
- **Users**: Basic user profiles with email authentication
- **Accounts**: OAuth account connections (YouTube/TikTok per user)
- **Channels**: Tracked YouTube channels with metadata
- **Videos**: Individual video records with processing status
- **Jobs**: Processing queue with status tracking and progress

## Data Flow

1. **User Onboarding**: OAuth authentication with YouTube/TikTok accounts
2. **Channel Setup**: Users input YouTube channel URLs to track
3. **Video Discovery**: Background polling of YouTube API for new videos
4. **Job Creation**: User selects videos to mirror, creating processing jobs
5. **Processing Pipeline**:
   - Download original video using yt-dlp
   - Generate optimized content using Gemini AI
   - Upload to selected platforms (YouTube Shorts/TikTok)
   - Update job status and store results
6. **Status Monitoring**: Real-time updates on processing progress

## External Dependencies

### APIs & Services
- **YouTube Data API v3**: Channel and video metadata retrieval
- **YouTube Upload API**: Shorts video uploads
- **TikTok API v2**: Video uploads and user authentication
- **Google Gemini API**: AI content generation for SEO optimization
- **Neon Database**: Serverless PostgreSQL hosting

### Key Libraries
- **@google/genai**: Gemini AI integration
- **@neondatabase/serverless**: Database connectivity
- **drizzle-orm**: Type-safe database operations
- **@tanstack/react-query**: Client-side data fetching
- **@radix-ui/***: Accessible UI component primitives

## Deployment Strategy

### Development
- **Dev Server**: Vite dev server with Express API proxy
- **Database**: Development migrations via Drizzle Kit
- **Environment**: Hot reload for both frontend and backend

### Production Build
- **Frontend**: Vite production build with static asset optimization
- **Backend**: ESBuild bundling with Node.js platform targeting
- **Database**: Production schema deployment via Drizzle migrations
- **Process Management**: Single Node.js process serving both API and static files

### Environment Configuration
- OAuth credentials for YouTube and TikTok APIs
- Database connection string for Neon PostgreSQL
- Gemini API key for content generation
- Redis connection for production session management (recommended)

### Scalability Considerations
- Queue system designed for horizontal scaling
- Database schema optimized for concurrent operations
- Stateless API design for load balancer compatibility
- CDN-ready static asset structure

## Demo Features Available

### User Experience
- **Demo Login**: Simple email-based demo authentication (demo@mirrorclip.com)
- **Sample Data**: Pre-loaded Linus Tech Tips channel with 3 sample videos
- **Connected Accounts**: Simulated YouTube and TikTok account connections
- **Processing Simulation**: Full workflow demonstration without actual video processing

### Core Functionality
- **Channel Tracking**: Add and monitor YouTube channels for new content
- **Video Discovery**: Browse and select videos from tracked channels
- **AI Content Generation**: Generate SEO-optimized titles, captions, and hashtags using Gemini
- **Processing Queue**: Real-time job status monitoring with progress updates
- **Multi-platform Upload**: Simulated uploads to YouTube Shorts and TikTok

### Technical Implementation
- **Frontend**: React 18 + TypeScript with shadcn/ui components
- **Backend**: Express.js with TypeScript and comprehensive API
- **Database**: In-memory storage with full CRUD operations
- **Authentication**: Session-based demo system with 30-day expiration
- **AI Service**: Google Gemini integration for content optimization
- **Real-time Updates**: Polling-based status updates every 5 seconds

## Next Steps for Production
1. Replace in-memory storage with PostgreSQL database
2. Implement real OAuth flows for YouTube and TikTok
3. Add actual video processing with yt-dlp
4. Set up Redis for queue management
5. Add error handling and retry mechanisms
6. Implement user management and subscription system